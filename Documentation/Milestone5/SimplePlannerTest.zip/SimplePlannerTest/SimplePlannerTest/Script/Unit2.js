﻿

function loggingIn()
{
  var browser;
  var page;
  var form;
  var textbox;
  var passwordBox;
  Aliases.explorer.wndShell_TrayWnd.ReBarWindow32.MSTaskSwWClass.MSTaskListWClass.Click(281, 10);
  Browsers.Item(btChrome).Navigate("https://support.smartbear.com/testcomplete/docs/tutorials/getting-started/first-test/web/running-recorded-test.html");
  browser = Aliases.browser;
  browser.ToUrl("https://simpleplanner.herokuapp.com/");
  browser.pageSimpleplannerHerokuappCom.link2.Click();
  page = browser.pageSimpleplannerHerokuappComFro;
  page.Wait();
  form = page.form;
  textbox = form.textboxUname;
  textbox.Click(170, 15);
  page.SetText("s");
  textbox.Click(21, 19);
  textbox.SetText("user205@gmail.com");
  passwordBox = form.passwordboxPsw;
  passwordBox.Click(47, 22);
  passwordBox.SetText("passeD5!");
  form.buttonLogin.ClickButton();
  browser.pageSimpleplannerHerokuappComBac.Wait();
}
﻿function createEvent()
{
  var browser;
  var page;
  var form;
  var textbox;
  Browsers.Item(btChrome).Navigate("https://simpleplanner.herokuapp.com/Backend/login_handler.php?uname=user205%40gmail.com&psw=passeD5%21");
  browser = Aliases.browser;
  browser.ToUrl("https://simpleplanner.herokuapp.com/");
  page = browser.pageSimpleplannerHerokuappCom;
  page.buttonCreateEvent.ClickButton();
  form = page.form;
  textbox = form.textboxEventtitle;
  textbox.Click(399, 31);
  textbox.SetText("Birthday Party");
  textbox = form.textboxStarttime;
  textbox.Click(411, 25);
  textbox.SetText("1");
  textbox.Keys("[Down][Tab]");
  textbox = form.textboxEndtime;
  textbox.SetText("4pm");
  textbox.Keys("[Tab]");
  textbox = form.textboxLocation;
  textbox.SetText("Kevin\'s house");
  textbox.Keys("[Tab]");
  form.textboxHost.SetText("John Smith");
  textbox = form.textboxDescription;
  textbox.Click(490, 24);
  textbox.SetText("Balloons and presents. Dress casually");
  form.submitbuttonCreateEvent.ClickButton();
  browser.pageSimpleplannerHerokuappComBac2.Wait();
}